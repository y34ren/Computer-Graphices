package Question1;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.io.*;

/*PPM_img 
 * input  (int) : Width and Height
 * output 		: A display of the image 
 */


//Start

public class PPM_img extends JFrame{

	//create display window
	private JPanel mainPanel;
	
	//array for all the colors
	int[][][] ColorArray;
	
	//Function 
	//input width & height
	//out put image
	public PPM_img(final int SizeX, final  int SizeY){
		
		mainPanel = new JPanel(){
			
			// function paint
			// input graphic
			// output graphic
			@Override
			public void paint(Graphics g) {

				// Array with dimension of width by height by 3
				// index for width
				// index of height
				// index of RGB

				ColorArray = new int[SizeX][SizeY][3];

				//set constants
				int x2 = SizeX / 2;
				int y2 = SizeY / 2;
				int x1 = 0;
				int y1 = 0;


				int ChangeY = y2 - y1;
				int ChangeX = x2 - x1;
				int ChangeY2 =  ChangeY *2;
				int ChangeX2 =  ChangeX *2;
				int d = ChangeY2 - ChangeX;
				int ChangeYX2 = (ChangeY - ChangeX) *2;
				int ChangeXY2 = (ChangeX - ChangeY) *2;

				//input values into the color array.
				//color left half the graph RED with Gradient.
				for(int x = 0; x <= x2;x++){

					for(int y = 0; y < SizeY; y++){

						ColorArray[x][y][0] = 255 * x/x2;
						ColorArray[x][y][1] = 0;
						ColorArray[x][y][2] = 0;

					}

					g.setColor(new Color( 255 * x/x2, 0, 0));
					g.drawLine(x, 0, x, SizeY);

				}
				
				//input values into the color array.
				//color right half the graph BLUE with Gradient.
				for(int x = SizeX-1; x > x2;x--){  

					for(int y = 0; y < SizeY; y++){

						
						ColorArray[x][y][0] = 0;
						ColorArray[x][y][1] = 0;
						ColorArray[x][y][2] = 255 * (SizeX - x) / x2;

					}

					g.setColor(new Color(0, 0, 255 * (SizeX - x) / x2));
					g.drawLine(x, 0, x, SizeY);


				}  


				//set bottom and top border value to black
				for(int i = x1; i < SizeX - x1; i++){

					
					ColorArray[i][0][0] = 0;
					ColorArray[i][0][1] = 0;
					ColorArray[i][0][2] = 0;
					ColorArray[i][SizeY -1][0] = 0;
					ColorArray[i][SizeY  - 1][1] =0;
					ColorArray[i][SizeY -1 ][2] = 0;

				}
				
				
				//set bottom and top border color to black
				g.setColor(new Color( 0, 0, 0)); 
				g.drawLine(x1, y1, SizeX - x1, y1);

				g.setColor(new Color( 0,0,0)); 
				g.drawLine( x1, SizeY - y1, SizeX - x1 , SizeY - y1 );

				//condition height great then width, therefore the degree is greater than 45
				if (SizeY > SizeX){
					
					//Bresenham��s Line Algorithm
					//Integer implementation
					//finding the line separate the colors
					while(y1 < y2){
						if (d<=0){
							d += ChangeX2; 
						}
						else {
							d += ChangeXY2;
							x1++;
						}
						y1++;

					//set value to the top triangle with GREEN  Gradient to black
						for(int i = x1; i < SizeX - x1; i++){

							ColorArray[i][y1][0] = 0;
							ColorArray[i][y1][1] = 255* y1/y2;
							ColorArray[i][y1][2] = 0;

						}
						// paint top triangle
						g.setColor(new Color( 0, 255* y1/y2, 0));
						g.drawLine(x1, y1, SizeX - x1, y1);

						//with inverse to set value of the bottom triangle  with white	Gradient to black
						for(int i = x1; i < SizeX - x1; i++){

							ColorArray[i][SizeY - y1 - 1][0] = 255 * y1 /y2;
							ColorArray[i][SizeY - y1 -1 ][1] = 255 * y1 /y2;
							ColorArray[i][SizeY - y1 -1 ][2] = 255 * y1 /y2;

						}
						//paint the bottom triangle 
						g.setColor(new Color( 255 * y1 /y2, 255* y1/y2, 255* y1/y2)); 
						g.drawLine( x1, SizeY - y1, SizeX - x1 , SizeY - y1 );

					}
				}
				
				//condition width greater or equal to height, therefore the degree is less than 45
				//Bresenham��s Line Algorithm
				//Integer implementation
				//finding the line separate the colors
				while(x1 < x2){
					if (d<=0){
						d += ChangeY2; 
					}
					else {
						d += ChangeYX2;
						y1++;
					}
					x1++;

					//set value to the top triangle with GREEN  Gradient to black
					for(int i = x1; i < SizeX - x1; i++){

						ColorArray[i][y1][0] = 0;
						ColorArray[i][y1][1] = 255* y1/y2;
						ColorArray[i][y1][2] = 0;

					}
					//color top trangle
					g.setColor(new Color( 0, 255* y1/y2, 0));
					g.drawLine(x1, y1, SizeX - x1, y1);

					//set value to the bottom triangle with GREEN  Gradient to black
					for(int i = x1; i < SizeX - x1; i++){

						ColorArray[i][SizeY - y1 -1][0] = 255 * y1 /y2;
						ColorArray[i][SizeY - y1 -1][1] = 255 * y1 /y2;
						ColorArray[i][SizeY - y1 -1][2] = 255 * y1 /y2;

					}
					//color bottom triangle
					g.setColor(new Color( 255 * y1 /y2, 255* y1/y2, 255* y1/y2)); 
					g.drawLine( x1, SizeY - y1, SizeX - x1 , SizeY - y1 );


				}

				
			}


		};


		//add main panel to Window
		//set Window size
		//function end when GUI is closer, not the graph window
		
		add(mainPanel);
		setSize(SizeX + 100, SizeY + 100);
		setVisible(true);

	}
//END	






}