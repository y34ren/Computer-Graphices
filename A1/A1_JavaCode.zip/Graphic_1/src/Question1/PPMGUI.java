package Question1;




import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.TitledBorder;

/*
 * GUI for PPM_img.java
 */

public class PPMGUI  extends JFrame {

	//Data field
	//All Panel,Button,and TextArea and an empty ArrayBag

	//panel
	public JPanel mp;  //main panel  
	public JPanel p1;  // panel_1 - contain Label1, Lable2, Textfield1. and TextField2.
	public JPanel p2; // panel_2 - contain Button view and button save

	//textField
	public JTextField t1; 
	public JTextField t2;

	//Label
	public JLabel l1;  //Width
	public JLabel l2;  //Height

	//button
	public JButton View;
	public JButton Save;

	//PPM_img
	public PPM_img T;



	// Creating PPMGUI

	//start

	public PPMGUI(){

		//Creating Main Panel
		mp = new JPanel();
		mp.setLayout(new BoxLayout(mp, BoxLayout.Y_AXIS));

		//Adding Main Panel to the Frame
		add(mp);


		//set ALL Labels, Buttons to frame	
		t1 = new JTextField();
		t2 = new JTextField();
		l1 = new JLabel ("Width: ");
		l2 = new JLabel ("Height: ");


		p2 = new JPanel();
		p2.setBorder(new TitledBorder("INFO"));
		p2.setLayout(new GridLayout(2,2));
		p2.add(l1);
		p2.add(t1);
		p2.add(l2);
		p2.add(t2);
		mp.add(p2);




		//Creating All buttons

		p1= new JPanel();
		p1.setBorder(new TitledBorder(""));
		p1.setLayout(new GridLayout(1,2));


		View = new JButton("View");
		View.addActionListener(new View());



		Save = new JButton("Save");
		Save.addActionListener(new Save());

		p1.add(View);
		p1.add(Save);

		mp.add(p1);



	}

	//Creating Button ActionListener
	//View Image, Save Image to PPM file
	/**
	 * 
	 * @author yifeiren
	 *
	 */

	//View function

	public class View implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			//read in width & height
			//call PPM_img.java create image and viewing window
			try{
				Integer.parseInt(t1.getText());
				Integer.parseInt(t2.getText());
				T = new PPM_img((Integer.parseInt(t1.getText())) , (Integer.parseInt(t2.getText())));
			}
			catch (NumberFormatException e1){
				//error message
				JOptionPane.showMessageDialog(null, "Please Enter an integers as your Hight / Width" );
			}


		}

	}

	//Save Function
	public class Save implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			//create String array for each line

			ArrayList<String> lines = new ArrayList<String>(); // file lines
			lines.add("p3"); // add image header
			lines.add(t1.getText() + " " + t2.getText()); //add size
			lines.add("255"); // add max color

			//Save array toString to file as Result.ppm 
			for (int y = 0; y < (Integer.parseInt(t2.getText())); y++) {
				String l = "";
				for (int x = 0; x < (Integer.parseInt(t1.getText())); x++) {
					for (int z = 0 ; z < 3; z++){
						l += T.ColorArray[x][y][z] + " ";
					}
				}

				lines.add(l.trim());
			}
			PrintWriter writer = null;
			try {
				writer = new PrintWriter("Result.ppm");
				for (String i : lines)
					writer.println(i);
			} catch (FileNotFoundException ee) {
				// TODO Auto-generated catch block
				ee.printStackTrace();
			}
			finally
			{
				if ( writer != null)
					writer.close( );
			}
			//display falue successfully saved
			JOptionPane.showMessageDialog(null, "File saved!" );


		}

	}


	//View PPMGUI window
	public static void main(String args[]){
		PPMGUI DG= new PPMGUI();
		DG.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		DG.setVisible(true);
		DG.setSize(300,200);
		DG.setTitle("PPM Image");
	}


}

//end

