package Question2;




import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

	import javax.swing.*;
import javax.swing.border.TitledBorder;



	public class EllipseGUI  extends JFrame {

		//Data fields
		//All Panel,Button,and TextArea and an Ellipse()

		
		public JPanel mp;
		
		public JPanel p1;

		public JPanel p2;
		

		public JTextField t1;
		public JTextField t2;
		
		public JLabel l1;
		public JLabel l2;
		
		
		public JButton View;
		

		public Ellipse E;
		
		

		// Creating EllipseGUI

		public EllipseGUI(){

			//Creating Main Panel with vertical layout
			mp = new JPanel();
			mp.setLayout(new BoxLayout(mp, BoxLayout.Y_AXIS));

			//Adding Main Panel to the Frame
			add(mp);

			
			//Adding TextField, Labels, and Button
			
			t1 = new JTextField();
	        t2 = new JTextField();
	        l1 = new JLabel ("Radius-X: "); // horizontally radius  along the x-axis
	        l2 = new JLabel ("Radius-Y: "); //vertically radius  along the y-axis
	        

	        //top panel with Label and TextFields
	        p2 = new JPanel();
	        p2.setBorder(new TitledBorder("INFO"));
			p2.setLayout(new GridLayout(2,2));
			p2.add(l1);
	        p2.add(t1);
	        p2.add(l2);
	        p2.add(t2);
			mp.add(p2);
	        
	
			

			//Creating All buttons to bottom panel
			// View  button
			p1 = new JPanel();
			p1.setBorder(new TitledBorder(""));
			p1.setLayout(new GridLayout(1,2));
			
			
			View = new JButton("View");
			View.addActionListener(new View());
			

			p1.add(View);

			mp.add(p1);
		


		}

		//Creating Button ActionListener
		//Creating View Button function
		/**
		 * 
		 * @author yifeiren
		 *
		 */

		public class View implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				
				//Read in Radius-X and Radius-Y as integer
				try{
					//check for integer
					Integer.parseInt(t1.getText());
					Integer.parseInt(t2.getText());
					
					EventQueue.invokeLater(new Runnable() {
						
						@Override
						public void run( ) {
							try {
								UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
							} catch (Exception e) {
								e.printStackTrace();
							}
							
							// Call function Ellipse(Radius-X, Radius-Y) 
							// Creating Ellipse in a viewing Window

							E = new Ellipse(Integer.parseInt(t1.getText()), Integer.parseInt(t2.getText()));
							JFrame window = new JFrame();
							window.setSize(Integer.parseInt(t1.getText()) * 20 + 50, Integer.parseInt(t2.getText()) * 20  + 80);  //w+40, h +40
							window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
							window.add(E);
							window.setVisible(true);
						}
					});
				
				}
				
				//errors
				catch (NumberFormatException e1){
					JOptionPane.showMessageDialog(null, "Please Enter an integers as your Hight / Radius-X" );
				}
			    

			}

		}
		
		
		

		//Create GUI
		public static void main(String args[]){
			EllipseGUI DG= new EllipseGUI();
			DG.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			DG.setVisible(true);
			DG.setSize(300,200);
			DG.setTitle("EllipseGUI");
		}


	}
	
	//END


