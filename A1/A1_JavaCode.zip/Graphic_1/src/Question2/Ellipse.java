package Question2;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/*Ellipse.java
 * Create Grid
 * Paint Grid
 * Draw Ellipse 
 *
 */

//start

public class Ellipse extends JPanel{

	//global value 

	int width;  // each grid is 10X10, therefore the total width will be input width value times 20
	int height; // each grid is 10X10, therefore the total width will be input height value times 20

	int	 a; // input value width
	int	 b;	// input value height

	//constants
	int aa ;  // a*a
	int bb ; // b*b

	int q; //x point when slope equals to -1 

	//create Array for all cells
	private List<Point> fillCells;

	//create Ellipse 
	//input width and height
	//Ellipse (width, height)

	public Ellipse(int a, int b) {

		//set values
		width = a * 20;
		height = b * 20;

		this.a = a;
		this.b = b;

		aa = a*a;
		bb = b*b;
		this.q = aa * aa / (bb + aa);


		fillCells = new ArrayList<Point>((width + height)/2);

	}




	//Draw Grid && Draw Ellipse and fill Cell using Mid point Ellipse Algorithm 
	@Override
	protected void paintComponent(Graphics g) {

		super.paintComponent(g);

		drawGrid(g, width + 30, height + 30);

		drawEllipse (g, width , height );

		BAlgorithm();

	}

	//fill Cell function giving (x,y) position with RED color

	public void fillCell(int x, int y) {
		fillCells.add(new Point(x, y));
		repaint();
	}

	//drawing 10x10 Grid 
	//RED as cell fillings
	//Black as lines
	public void drawGrid (Graphics g, int width, int height){


		for (Point fillCell : fillCells) {
			int cellX = 10 + (fillCell.x * 10);
			int cellY = 10 + (fillCell.y * 10);
			g.setColor(Color.RED);
			g.fillRect(cellX, cellY, 10, 10);			
		}

		g.setColor(Color.BLACK);
		g.drawRect(10, 10, width, height);

		for (int i = 10; i <= width; i += 10) {
			g.drawLine(i, 10, i, height + 10);
		}

		for (int i = 10; i <= height; i += 10) {
			g.drawLine(10, i, width + 10, i);
		}
	}

	//Draw Ellipse 
	//input start point x & y from left most corner,  width and height
	public void drawEllipse (Graphics g, int width, int height){

		Graphics2D g2 = (Graphics2D) g;

		g2.draw(new Ellipse2D.Double(25, 25, width, height));



	}


	//Using Mid point Ellipse Algorithm 
	//Ellipse has four equal parts
	//Condition two regions (slope 0 to -1, and slope to -infinity)

	public void BAlgorithm (){

		//setting constants

		int twoAA = 2 * aa;
		int twoBB = 2 * bb;
		int p, x = 0 , y = b;
		int px = 0, py = twoAA * y;

		//fill cell at starting point for each of the equal parts

		this.fillCell(x+a+1, y+b+1);
		this.fillCell(-x+a+1, y+b+1);
		this.fillCell(x+a+1, -y+b+1);
		this.fillCell(-x+a+1, -y+b+1);


		//Region 1 
		//Region slope for -1 to 0

		//mid point
		p = (int)Math.round((bb - (aa * b) + (0.25 * aa)));

		//Mid point Ellipse Algorithm  (explain in Word file) 
		while (px < py){
			x++;
			px += twoBB;
			if (p < 0) {
				p += bb + px;
			}
			else {
				y--;
				py -= twoAA;
				p += bb + px - py;
			}

			//filling the right Cells for each equal parts
			this.fillCell(x+a+1, y+b+1);
			this.fillCell(-x+a+1, y+b+1);
			this.fillCell(x+a+1, -y+b+1);
			this.fillCell(-x+a+1, -y+b+1);


		}

		//Region 2
		//slope from -1 to -infinity

		//mid point
		p = (int)Math.round(bb * (x+0.5) *(x+0.5) + aa * (y - 1)* (y-1) - aa * bb);

		//Mid point Ellipse Algorithm  (explain in Word file) 
		while (y > 0){
			y--;
			py -= twoAA;
			if (p > 0){
				p += aa - py;

			}
			else {
				x++;
				px += twoBB;
				p += aa - py + px;

			}

			//Filling Cell in Region 2
			this.fillCell(x+a+1, y+b+1);
			this.fillCell(-x+a+1, y+b+1);
			this.fillCell(x+a+1, -y+b+1);
			this.fillCell(-x+a+1, -y+b+1);


		}

	}



}

//End