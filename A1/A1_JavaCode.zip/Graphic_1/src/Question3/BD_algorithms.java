package Question3;

//Burkes Dithering algorithms (will explain it in Word file)

public class BD_algorithms { 

	//data fields
	public int[][] colorArray;  //Saving all the colors
	public int width, height; 	//graph's height and width
	public int maxColor;		//color range

	//start

	//BD_algorithms
	//input Array,width, height, color range
	public BD_algorithms (int[][] colorArray, int width, int height, int maxColor){

		this.colorArray = colorArray;
		this.width = width;
		this.height = height;
		this.maxColor = maxColor;


	}
	//BD_algorithms function call

	public void BD_algorithms (){

		int oldColor;
		int newColor;
		int quant_error;

		/* It diffuses errors in the following pattern
		 *         X   8   4 
		 *  2   4   8   4   2
		 *      1/32
		 *      
		 *  starting at the top-left of the image and moving right    
		 */

		for (int y=0; y < height; y++ ){
			for (int x= 0; x< width; x++){
				oldColor = colorArray[x][y];  
				if (oldColor < maxColor/2){     // old color less than half of the color range, then old color is closer to black  
					newColor = 0;
					colorArray[x][y] = 1;		// set X to black
				}
				else {
					newColor = maxColor;		// else set color to white
					colorArray[x][y] = 0;
				}
				//error checking
				//bondry checking
				quant_error = oldColor - newColor;

				if (x+1  < width) 					colorArray[x + 1][y    ] +=  quant_error * 8 / 32;
				if (x+2  < width) 					colorArray[x + 2][y    ] +=  quant_error * 4 / 32;
				if (x-2  >=0 && y +1 < height)		colorArray[x - 2][y + 1] +=  quant_error * 2 / 32;
				if (x-1  >=0 && y +1 < height)		colorArray[x - 1][y + 1] +=  quant_error * 4 / 32;
				if (y+1  < height)					colorArray[x    ][y + 1] +=  quant_error * 8 / 32;
				if (x+1  < width && y+1 < height)	colorArray[x + 1][y + 1] +=  quant_error * 4 / 32;
				if (x+2  < width && y+1 < height)	colorArray[x + 2][y + 1] +=  quant_error * 2 / 32;



			}
		}

		//reset max color
		maxColor = 1;


	}



}

//END
