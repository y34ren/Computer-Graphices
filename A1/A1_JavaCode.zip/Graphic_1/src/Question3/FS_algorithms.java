package Question3;

//Floyd-Steinberg algorithm
public class FS_algorithms {

	//data fields
	public int[][] colorArray;  //Saving all the colors
	public int width, height; 	//graph's height and width
	public int maxColor;		//color range


	//start

	//BD_algorithms
	//input Array,width, height, color range
	public FS_algorithms (int[][] colorArray, int width, int height, int maxColor){

		this.colorArray = colorArray;
		this.width = width;
		this.height = height;
		this.maxColor = maxColor;


	}

	//FS_algorithms function call
	public void FS_algorithms (){

		int oldColor;
		int newColor;
		int quant_error;

		/* It diffuses errors in the following pattern
		 *         X   7   
		 *     3   5   1   
		 *      1/16
		 *      
		 *  starting at the top-left of the image and moving right    
		 */

		for (int y=0; y < height; y++ ){
			for (int x= 0; x< width; x++){
				oldColor = colorArray[x][y];
				if (oldColor < maxColor/2){
					newColor = 0;				// old color less than half of the color range, then old color is closer to black
					colorArray[x][y] = 1;		// set X to black
				}
				else {
					newColor = maxColor;	// else set color to white
					colorArray[x][y] = 0;
				}

				//error checking
				//bondry checking
				quant_error = oldColor - newColor;

				if (x+1  < width) 					colorArray[x + 1][y    ] += quant_error * 7 / 16;
				if (x-1  >=0 && y +1 < height)		colorArray[x - 1][y + 1] += quant_error * 3 / 16;
				if (y+1  < height)					colorArray[x    ][y + 1] += quant_error * 5 / 16;
				if (x+1  < width && y+1 < height)	colorArray[x + 1][y + 1] += quant_error * 1 / 16;


			}
		}
		//set new max color
		maxColor = 1;


	}



}

//END
