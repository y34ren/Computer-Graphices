package Question3;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import Question2.EllipseGUI;

//Start
// GUI converting P2 format image to P1 format image

public class P2toP1GUI  extends JFrame{

	//set data fields

	public JPanel mp;
	public JPanel p1;
	public JPanel p2;

	public JTextField tf1;

	public JButton chooseF;
	public JButton algor1;
	public JButton algor2;

	int[][] array;
	int[][] array2;
	int width;
	int height;
	int max;

	// Create both algorithms
	FS_algorithms FS;
	BD_algorithms BD;


	//GUI 
	public P2toP1GUI(){

		mp = new JPanel();
		mp.setLayout(new BoxLayout(mp, BoxLayout.Y_AXIS));

		add(mp);

		tf1 = new JTextField();
		tf1.disable();

		chooseF = new JButton ("Choose A File");
		chooseF.addActionListener( new ChooseF());


		p1 = new JPanel();
		p1.setBorder(new TitledBorder("INFO"));
		p1.setLayout(new GridLayout(2,1));

		p1.add(tf1);
		p1.add(chooseF);
		mp.add(p1);

		algor1 = new JButton ("Save as FS_algorithms");
		
		algor1.addActionListener( new algor1());  //Calling algorithm 1 - FS_algorithms (array, width, height, max);

		algor2 = new JButton ("Save as BD_algorithms");
		
		algor2.addActionListener( new algor2());	//Calling algorithm 2 - BD_algorithms (array, width, height, max);

		algor1.setEnabled(false);
		algor2.setEnabled(false);
		
		p2 = new JPanel();
		p2.setLayout(new GridLayout(1,2));

		p2.add(algor1);
		p2.add(algor2);

		mp.add(p2);


	}

	//Selecting files using JFile Chooser

	public class ChooseF implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			//open JFileChooser and select files
			JFileChooser chooser = new JFileChooser();
			chooser.showOpenDialog(null);

			//save file path to text field for user to see
			tf1.setText(chooser.getSelectedFile().toString());


			//Scanning file
			//it does not Check for blank line or #

			Scanner scan;
			try {
				//scan file and skip P2 header
				scan = new Scanner(chooser.getSelectedFile());
				scan.nextLine();
				String[] Size = scan.nextLine().split(" ");
				// save width and height
				width = Integer.parseInt(Size[0]);
				height = Integer.parseInt(Size[1]);


				//creating color array
				array = new int[width][height];
				array2 = new int[width][height];

				max =  Integer.parseInt(scan.nextLine());



				for (int i = 0; i< height;i++){
					for (int j = 0; j < width; j++ ){
						int color = Integer.parseInt(scan.next());
						array[j][i] = 	color;
						array2[j][i] = color;
					}
					scan.nextLine();

				}


				//catch error 
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			algor1.setEnabled(true);
			algor2.setEnabled(true);
		}
		
	}


	//algorithm 1 - FS_algorithms (array, width, height, max);

	public class algor1 implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			FS = new FS_algorithms (array, width, height, max);
			// call FS_algorithms (array, width, height, max);
			FS.FS_algorithms();
			// adding P1 header and width height to file first line and second
			ArrayList<String> lines = new ArrayList<String>(); // file lines
			lines.add("P1"); // magic header
			lines.add(width + " " + height); // size

			//convert to new colors to array and save to file
			for (int y = 0; y < height; y++) {
				String l = "";
				for (int x = 0; x < width; x++) {

					l += FS.colorArray[x][y] + " ";

				}

				lines.add(l.trim());
			}
			PrintWriter writer = null;
			try {
				writer = new PrintWriter("ResultFS.pbm");  //save to file Name ResultFS.pbm
				for (String i : lines)
					writer.println(i);
			} catch (FileNotFoundException ee) {
				// TODO Auto-generated catch block
				ee.printStackTrace();
			}
			finally
			{
				if ( writer != null)
					writer.close( );
			}
			// show save successful
			JOptionPane.showMessageDialog(null, "File saved!" );
			algor1.setEnabled(false);
			
		}
	}

	//algorithm 2 - BD_algorithms (array, width, height, max);
	public class algor2 implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			BD = new BD_algorithms (array2, width, height, max);

			// call BD_algorithms (array, width, height, max);
			BD.BD_algorithms();

			// adding P1 header and width height to file first line and second
			ArrayList<String> lines = new ArrayList<String>(); // file lines
			lines.add("P1"); // image header
			lines.add(width + " " + height); // size

			// convert to new colors to array and save to file
			for (int y = 0; y < height; y++) {
				String l = "";
				for (int x = 0; x < width; x++) {

					l += BD.colorArray[x][y] + " ";

				}

				lines.add(l.trim());
			}
			PrintWriter writer = null;
			try {
				writer = new PrintWriter("ResultBD.pbm");
				for (String i : lines)
					writer.println(i);
			} catch (FileNotFoundException ee) {
				// TODO Auto-generated catch block
				ee.printStackTrace();
			}
			finally
			{
				if ( writer != null)
					writer.close( );
			}
			// show save successful
			JOptionPane.showMessageDialog(null, "File saved!" );
			
			algor2.setEnabled(false);
		}
	}

	//create GUI window
	public static void main(String args[]){
		P2toP1GUI gui= new P2toP1GUI ();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setVisible(true);
		gui.setSize(300,200);
		gui.setTitle("ImageProcess");
	}



}
//end
