import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.io.*;

/* 
 * This class show a frame to set the size
 * There is a main to star this program
 * in this class, there are functions to save files
 */
public class windows extends JFrame implements ActionListener {
	// the Max color
	private final static int MaxColor = 255;
	// four colors of sides
	private final static myColor topcolor = new myColor(0, MaxColor, 0);
	private final static myColor leftcolor = new myColor(MaxColor, 0, 0);
	private final static myColor rightcolor = new myColor(0, 0, MaxColor);
	private final static myColor botcolor = new myColor(MaxColor, MaxColor, MaxColor);

	// components in frame
	JTextField textbox1;
	JTextField textbox2;

	// the main function
	// program should run star from here
	public static void main(String[] args) {
		// create frame
		windows myWindow = new windows("Assignment 1");
		// set what frame should to do when close window
		myWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Size the frame.
		myWindow.setSize(300, 150);
		// Show it.
		myWindow.setVisible(true);
	}

	// initialization class
	// create the frame
	public windows(String title) {
		// set title
		super(title);

		// ----- Create components and put them in the frame.
		// Panel
		JPanel panel1 = new JPanel();
		panel1.setLayout(new GridLayout(2, 2));
		// Panel
		JPanel panel2 = new JPanel();
		// lable 1
		JLabel label1 = new JLabel("Width:");
		// lable 2
		JLabel label2 = new JLabel("Height:");
		// textbox 1
		textbox1 = new JTextField();
		// textbox 2
		textbox2 = new JTextField();
		// Button 1
		JButton button1 = new JButton("Save File");
		button1.addActionListener(this);

		// ----- Add all components
		// add components in panel 1
		panel1.add(label1, BorderLayout.WEST);
		panel1.add(textbox1, BorderLayout.EAST);
		panel1.add(label2, BorderLayout.WEST);
		panel1.add(textbox2, BorderLayout.EAST);
		// add components in panel 2
		panel2.add(button1, BorderLayout.CENTER);
		// add panels to frame
		add(panel1, BorderLayout.CENTER);
		add(panel2, BorderLayout.SOUTH);
	}

	// create files
	public void actionPerformed(ActionEvent e) {
		int width, height;// size
		// read size from textbox
		width = Integer.parseInt(textbox1.getText().trim());
		height = Integer.parseInt(textbox2.getText().trim());
		// initialization color array
		myColor[][] colorarray = new myColor[width][height];

		// ----- Bresenham��s Line Algorithm
		// get the half of size, because this image is Symmetrical
		// we just need to do A quarter of left-top corner
		// I make the color with line by line
		// so I need a variable to determine the color of the demarcation point
		// each line i just need do a while until y++
		// and save the x. this x is the demarcation point
		int halfwidth = width / 2 + width % 2;
		int halfheight = height / 2 + height % 2;
		// initialization demarcation point
		int dividing = 0;
		// distance difference
		int d;
		// Determine the slope
		if (width >= height)
			d = 2 * halfheight - halfwidth;
		else
			d = 2 * halfwidth - halfheight;
		// loop line by line
		for (int y = 0; y < halfheight; y++) {
			float py = (float) y / halfheight; // set percentage by y
			for (int x = 0; x < halfwidth; x++) {
				float px = (float) x / halfwidth; // set percentage by x
				// set color
				myColor r1, r2;
				if (x < dividing) { // left color or right color
					r1 = leftcolor.setPercentage(px);
					r2 = rightcolor.setPercentage(px);
					colorarray[x][y] = r1;// left-top
					colorarray[x][height - y - 1] = r1;// right-top
					colorarray[width - x - 1][y] = r2;// left-bot
					colorarray[width - x - 1][height - y - 1] = r2;// right-bot
				} else { // top & bot
					r1 = topcolor.setPercentage(py);
					r2 = botcolor.setPercentage(py);
					colorarray[x][y] = r1;// left-top
					colorarray[width - x - 1][y] = r1;// right-top
					colorarray[x][height - y - 1] = r2;// left-bot
					colorarray[width - x - 1][height - y - 1] = r2;// right-bot
				}
			}
			// star Bresenham��s Line Algorithm to decide next demarcation point
			if (width >= height) {// Determine the slope
				while (d < 0 && dividing < halfwidth) {
					d += 2 * halfheight;
					dividing++;
				}
				d += (halfheight - halfwidth) * 2;
				dividing++;
			} else {
				if (d < 0)
					d += 2 * halfwidth;
				else {
					d += (halfwidth - halfheight) * 2;
					dividing++;
				}
			}
		}

		// file lines
		ArrayList<String> lines = new ArrayList<String>(); // file lines
		lines.add("P3"); // magic header
		lines.add(width + " " + height); // size
		lines.add(Integer.toString(MaxColor)); // the max color
		for (int y = 0; y < height; y++) {
			String l = "";
			for (int x = 0; x < width; x++) {
				if (colorarray[x][y] == null) {
					l += null;
				} else {
					l += colorarray[x][y].toString() + " ";// merge each lines
				}
			}
			lines.add(l.trim());// add lines to list
		}

		// save file by lines list
		try (PrintWriter out = new PrintWriter("Result.ppm")) {
			for (String i : lines)
				out.println(i);
		} catch (FileNotFoundException ee) {
			ee.printStackTrace();
		}

		// ================================================== create gray scale
		// image for question 3
		// because question 3 need a gray scale, here are a addition to save it
		// everything same as above
		// the algorithm of color to gray is in the color class

		// file lines
		lines = new ArrayList<String>(); // file lines
		lines.add("P2"); // magic header
		lines.add(width + " " + height); // size
		lines.add(Integer.toString(MaxColor)); // the max color
		for (int y = 0; y < height; y++) {
			String l = "";
			for (int x = 0; x < width; x++) {
				if (colorarray[x][y] == null) {
					l += null;
				} else {
					l += colorarray[x][y].graytostring() + " ";
				}
			}
			lines.add(l.trim());
		}

		// save file
		try (PrintWriter out = new PrintWriter("input.pgm")) {
			for (String i : lines)
				out.println(i);
		} catch (FileNotFoundException ee) {
			ee.printStackTrace();
		}

		// here is a Dialog info to show save finished
		JOptionPane.showMessageDialog(this, "File saved successfuly.", "Message", JOptionPane.PLAIN_MESSAGE);
	}
}