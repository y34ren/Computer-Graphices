/* 
 * This class use for processing color information
 * There are three integer variables to save color info 
 */

public class myColor {
	// color info
	public int red;
	public int green;
	public int blue;

	// initialization class by default
	public myColor() {
		this.red = 0;
		this.green = 0;
		this.blue = 0;
	}

	// initialization class by three three integer variables
	public myColor(int r, int g, int b) {
		this.red = r;
		this.green = g;
		this.blue = b;
	}

	// initialization class by other color (use for clone)
	public myColor(myColor color) {
		this.red = color.red;
		this.green = color.green;
		this.blue = color.blue;
	}

	// return a dark color by percentage
	public myColor setPercentage(float percentage) {
		myColor result = new myColor(this);
		result.red *= percentage;
		result.green *= percentage;
		result.blue *= percentage;
		return result;
	}

	// return a string for saving file
	public String toString() {
		return red + " " + green + " " + blue;
	}

	// ================================================== create gray scale
	// image info for question 3
	// make a gray scale by image with color
	// This algorithm is through the color of the human recognition of the
	// degree of the image processing
	public String graytostring() {
		return Math.round(0.21f * red + 0.72f * green + 0.07f * blue) + "";
	}
}