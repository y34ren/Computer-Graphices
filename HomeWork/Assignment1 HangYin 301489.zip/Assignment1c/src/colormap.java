import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/*
 * This class use for Processing image (color map) information
 * it saves a color map, size and max value of color
 */

public class colormap {
	public color map[][];// color map
	public int x, y;// size
	public int max;// max value of color

	// initialization by other color map (use for clone)
	public colormap(colormap cm) {
		this.map = cm.map.clone();
		this.x = cm.x;
		this.y = cm.y;
		this.max = cm.max;
	}

	// initialization by file (read a .pgm file)
	public colormap(String filepath) throws IOException {
		// read input file
		@SuppressWarnings("resource")
		BufferedReader in = new BufferedReader(new FileReader(filepath));
		String str;// lines string
		int star = 0;// count of lines
		ArrayList<String> lines = new ArrayList<String>();// use save color info
															// by string
		while ((str = in.readLine()) != null) {
			if (star > 3) { // read color lines
				String s[] = str.split(" ");// split by space
				for (int i = 0; i < s.length; i++)
					lines.add(s[i].trim());
			} else { // read magic head
				if (str.charAt(0) != '#') { // read without note
					star++;// count Effective lines
					if (star == 2) { // read size
						String s[] = str.split(" ");
						// save size
						this.x = Integer.parseInt(s[0].trim());
						this.y = Integer.parseInt(s[1].trim());
					} else if (star == 3) { // read max value of color
						this.max = Integer.parseInt(str.trim());
					}
				}
			}
		}

		// add each color in map
		// just make string to int
		// and from a list to a 2D array
		this.map = new color[this.x][this.y];
		for (int yy = 0; yy < y; yy++)
			for (int xx = 0; xx < x; xx++)
				map[xx][yy] = new color(Integer.parseInt(lines.get(yy * x + xx).trim()), this.max);
	}

	// FloydSteinberg way to Processe color map
	// this way shoud Calculate the difference
	// and diffusion to around pixel
	//   X 7
	// 3 5 1 (1/16)
	public void FloydSteinberg() {
		for (int yy = 0; yy < y; yy++) {
			for (int xx = 0; xx < x; xx++) {
				// Calculate the difference
				int d = map[xx][yy].setDifference();
				// diffusion to around pixel
				if (xx + 1 < x)
					map[xx + 1][yy].value += d * 7 / 16;
				if (yy + 1 < y) {
					if (xx > 0)
						map[xx - 1][yy + 1].value += d * 3 / 16;
					map[xx][yy + 1].value += d * 5 / 16;
					if (xx + 1 < x)
						map[xx + 1][yy + 1].value += d * 1 / 16;
				}
			}
		}
		this.max = 1;
	}

	// Stucki way to Processe color map
	// this way shoud Calculate the difference
	// and diffusion to around pixel
	//     X 8 4
	// 2 4 8 4 2
	// 1 2 4 2 1 (1/42)
	public void Stucki() {
		for (int yy = 0; yy < y; yy++) {
			for (int xx = 0; xx < x; xx++) {
				// Calculate the difference
				int d = map[xx][yy].setDifference();
				// diffusion to around pixel
				if (xx + 1 < x)
					map[xx + 1][yy].value += d * 8 / 42;
				if (xx + 2 < x)
					map[xx + 1][yy].value += d * 4 / 42;
				if (yy + 1 < y) {
					if (xx > 1)
						map[xx - 2][yy + 1].value += d * 2 / 42;
					if (xx > 0)
						map[xx - 1][yy + 1].value += d * 4 / 42;
					map[xx][yy + 1].value += d * 8 / 42;
					if (xx + 1 < x)
						map[xx + 1][yy + 1].value += d * 4 / 42;
					if (xx + 2 < x)
						map[xx + 1][yy + 1].value += d * 2 / 42;
				}
				if (yy + 2 < y) {
					if (xx > 1)
						map[xx - 2][yy + 2].value += d * 1 / 42;
					if (xx > 0)
						map[xx - 1][yy + 2].value += d * 2 / 42;
					map[xx][yy + 2].value += d * 4 / 42;
					if (xx + 1 < x)
						map[xx + 1][yy + 2].value += d * 2 / 42;
					if (xx + 2 < x)
						map[xx + 1][yy + 2].value += d * 1 / 42;
				}
			}
		}
		this.max = 1;
	}

	// use for saving file to .pbm
	public void saveasfile(String filepath) {
		// file lines
		ArrayList<String> lines = new ArrayList<String>(); // file lines
		lines.add("P1"); // magic header
		lines.add(x + " " + y); // size
		for (int yy = 0; yy < y; yy++) {
			String l = "";
			for (int xx = 0; xx < x; xx++) {
				l += map[xx][yy].tostring() + " ";// Merge elements in a row
			}
			lines.add(l.trim());
		}

		// save file
		try (PrintWriter out = new PrintWriter(filepath)) {
			for (String i : lines)
				out.println(i);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
