import java.io.IOException;

/*
 * This class use for Controlling the operation of the entire program
 * this is the star for all program
 */

public class main {
	// the name of input file
	final static String InputName = "input.pgm";
	// the name of output files
	final static String FloydSteinbergName = "FloydSteinberg.pbm";
	final static String StuckiName = "Stucki.pbm";

	// The program starts from here
	public static void main(String[] args) throws IOException {
		// read file
		colormap FloydSteinberg = new colormap(InputName);
		colormap Stucki = new colormap(InputName);

		// dithering
		FloydSteinberg.FloydSteinberg();
		Stucki.Stucki();

		// save file
		FloydSteinberg.saveasfile(FloydSteinbergName);
		Stucki.saveasfile(StuckiName);
	}
}
