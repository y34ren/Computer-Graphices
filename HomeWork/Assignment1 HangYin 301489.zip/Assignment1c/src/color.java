/*
 * This class use for Store and process color information
 */

public class color {
	public int value;// the value of gray
	public int max;// the max value of gray

	// initialization by default
	public color() {
		this.value = 0;
		this.max = 1;
	}

	// initialization by value of gray and max value
	public color(int value, int max) {
		this.value = value;
		this.max = max;
	}

	// set color to the close one (black or white)
	// return the difference by old-new by old max value
	public int setDifference() {
		int r = value;// set the result, but not the final value
		if (value < max / 2) {// choose the cloose one
			value = 1;// set the value
		} else {
			value = 0;// set the value
			r -= max;// calculate difference
		}
		max = 1;// set max value
		return r;
	}

	// change value to string for saving file
	public String tostring() {
		return Integer.toString(value);
	}
}
