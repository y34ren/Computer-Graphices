import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class windows extends JFrame implements ActionListener {
	// size
	private int x = 0;
	private int y = 0;

	// components
	JTextField textbox1;
	JTextField textbox2;

	public windows(String title) {
		// set title
		super(title);
		// Create components and put them in the frame.
		// Panel
		JPanel panel1 = new JPanel();
		panel1.setLayout(new GridLayout(2, 2));
		// Panel
		JPanel panel2 = new JPanel();
		// lable 1
		JLabel label1 = new JLabel("X Radius:");
		// lable 2
		JLabel label2 = new JLabel("Y Radius:");
		// textbox 1
		textbox1 = new JTextField();
		// textbox 2
		textbox2 = new JTextField();
		// Button 1
		JButton button1 = new JButton("Save File");
		button1.addActionListener(this);

		// Add all components
		panel1.add(label1, BorderLayout.WEST);
		panel1.add(textbox1, BorderLayout.EAST);
		panel1.add(label2, BorderLayout.WEST);
		panel1.add(textbox2, BorderLayout.EAST);

		panel2.add(button1, BorderLayout.CENTER);

		add(panel1, BorderLayout.CENTER);
		add(panel2, BorderLayout.SOUTH);
	}

	// give size
	public void actionPerformed(ActionEvent e) {
		// read size
		x = Integer.parseInt(textbox1.getText().trim());
		y = Integer.parseInt(textbox2.getText().trim());
		// show draw window
		drawbord w = new drawbord(x, y);
	}

	public static void main(String[] args) {
		// create frame
		windows myWindow = new windows("Assignment 1");
		myWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Size the frame.
		myWindow.setSize(300, 150);
		// Show it.
		myWindow.setVisible(true);
	}
}