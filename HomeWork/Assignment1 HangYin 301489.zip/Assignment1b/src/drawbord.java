import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import javax.swing.*;

/*
 * there is a class use for showing the image by opengl
 * in the frame, i draw a web first
 * and i draw a ellipse
 * finally, i draw each points that are closest to the ellipse
 */

public class drawbord implements GLEventListener {
	// the radius of ellipse
	int radiusX;
	int radiusY;
	// the size of frame
	final int width = 800;
	final int height = 600;
	// the pixel pre unit
	final int CellSize = 50; // cell size

	// initialization by radius of ellipse
	public drawbord(int x, int y) {
		// set the radius
		radiusX = x;
		radiusY = y;
		// getting the capabilities object of GL2 profile
		final GLProfile profile = GLProfile.get(GLProfile.GL2);
		GLCapabilities capabilities = new GLCapabilities(profile);
		// The canvas
		final GLCanvas glcanvas = new GLCanvas(capabilities);
		glcanvas.addGLEventListener(this);
		glcanvas.setSize(width, height);
		// creating frame
		final JFrame frame = new JFrame("Draw Ellipse");
		// adding canvas to frame
		frame.getContentPane().add(glcanvas);
		// set frame size
		frame.setSize(frame.getContentPane().getPreferredSize());
		// show the frame
		frame.setVisible(true);
	}

	// use for initialization at the beginning
	@Override
	public void init(GLAutoDrawable arg0) {}

	// use for ending
	@Override
	public void dispose(GLAutoDrawable arg0) {}

	// use for draw things pre fps
	@Override
	public void display(GLAutoDrawable drawable) {
		final GL2 gl = drawable.getGL().getGL2();
		drawResult(gl);
	}

	// use for draw web,ellipse and points
	private void drawResult(GL2 gl) {
		// ----- draw webs
		gl.glBegin(GL2.GL_LINES); // static field
		gl.glColor3f(0.3f, 0.3f, 0.3f);// set color
		float cp, i;// this is cell percentage and counter
		// Vertical web line
		cp = (float) CellSize / width; // unit length
		i = 0f;
		while (i < 1) {
			// draw right
			gl.glVertex2f(i, 1f);
			gl.glVertex2f(i, -1f);
			// draw left
			gl.glVertex2f(-i, 1f);
			gl.glVertex2f(-i, -1f);
			// count
			i += cp;
		}
		// Horizontal web line
		cp = (float) CellSize / height; // unit length
		i = 0f;
		while (i < 1) {
			// draw right
			gl.glVertex2f(1f, i);
			gl.glVertex2f(-1f, i);
			// draw left
			gl.glVertex2f(1f, -i);
			gl.glVertex2f(-1f, -i);
			// count
			i += cp;
		}
		gl.glEnd();

		// ---------- draw ellipse
		drawEllipse(gl, 0f, 0f, radiusX, radiusY, false);

		// ----- Bresenham��s Algorithms
		// i just need draw A quarter of ellipse
		// because it is Symmetrical
		// for the quarter, it divided into two parts by slop = -1
		float xp2 = radiusX * radiusX;// save a constant: radius x^2
		float yp2 = radiusY * radiusY;// save a constant: radius y^2
		float Dividing = xp2 * xp2 / (xp2 + yp2);// this is the x of the point
													// of the slop = -1
		// ----- Region 1
		int x, y;
		// Initialize the start coordinates
		x = 0;
		y = Math.round(radiusY);
		// draw the point of ellipse
		do {
			drawEllipse(gl, x, y, 0.25f, 0.25f, true); // draw point right-top
			drawEllipse(gl, x, -y, 0.25f, 0.25f, true); // draw point right-bot
			drawEllipse(gl, -x, y, 0.25f, 0.25f, true); // draw point left-top
			drawEllipse(gl, -x, -y, 0.25f, 0.25f, true); // draw point left-bot
			x++;
			float d = 2 * yp2 * x * x + xp2 * y * y - 2 * xp2 * yp2;// Calculate
																	// the
																	// distance
																	// difference
			y--;
			d += xp2 * y * y;// Calculate the distance difference
			if (d < 0)
				y++;
		} while (x * x <= Dividing);
		// ----- Region 2
		// Initialize the start coordinates
		x = Math.round(radiusX);
		y = 0;
		do {
			drawEllipse(gl, x, y, 0.25f, 0.25f, true); // draw point right-top
			drawEllipse(gl, x, -y, 0.25f, 0.25f, true); // draw point right-bot
			drawEllipse(gl, -x, y, 0.25f, 0.25f, true); // draw point left-top
			drawEllipse(gl, -x, -y, 0.25f, 0.25f, true); // draw point left-bot
			y++;
			float d = yp2 * x * x + 2 * xp2 * y * y - 2 * xp2 * yp2;// Calculate
																	// the
																	// distance
																	// difference
			x--;
			d += yp2 * x * x;// Calculate the distance difference
			if (d < 0)
				x++;
		} while (x * x > Dividing);
	}

	// use for resize the frame
	@Override
	public void reshape(GLAutoDrawable arg0, int arg1, int arg2, int arg3, int arg4) {}

	//use for draw the ellipse by point, radius and isfull
	private void drawEllipse(GL2 gl, float x, float y, float rx, float ry, boolean full) {
		if (full) {
			gl.glBegin(GL2.GL_TRIANGLE_FAN);//choose full brush
			gl.glColor3f(0.5f, 0.75f, 1f);//set color
		} else {
			gl.glBegin(GL2.GL_LINE_LOOP);//choose line brush
			gl.glColor3f(0f, 0.25f, 1f);//set color
		}
		// draw ellipse
		for (int i = 0; i < 360; i++) {//loop the circle by angle
			float rad = (float) Math.toRadians(i);
			float xx = (float) (Math.cos(rad) * rx + x) * CellSize / width;
			float yy = (float) (Math.sin(rad) * ry + y) * CellSize / height;
			gl.glVertex2f(xx, yy);
		}
		gl.glEnd();
	}
}
